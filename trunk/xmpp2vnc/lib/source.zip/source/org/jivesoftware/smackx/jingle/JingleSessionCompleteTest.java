package org.jivesoftware.smackx.jingle;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smackx.nat.FixedResolver;
import org.jivesoftware.smackx.nat.STUNResolver;
import org.jivesoftware.smackx.nat.TransportCandidate;
import org.jivesoftware.smackx.nat.TransportResolver;
import org.jivesoftware.smackx.provider.JingleProvider;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: ThiagoC
 * Date: 05/10/2006
 * Time: 10:36:20
 * To change this template use File | Settings | File Templates.
 */

public class JingleSessionCompleteTest implements JingleListener.Session,
        JingleListener.SessionRequest {

    XMPPConnection con = null;

    JingleSession js = null;

    JingleManager jm = null;

    public JingleSessionCompleteTest(XMPPConnection con) {

        this.con = con;

        TransportResolver tr1 = new STUNResolver();

        try {
            System.out.println("Resolver Started");
            tr1.resolve();
        }
        catch (XMPPException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        try {
            while (!tr1.isResolved()) {
                System.out.println("resolving...");
                Thread.sleep(1000);
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }

        jm = new JingleManager(con, tr1);

        jm.addJingleSessionRequestListener(this);

    }

    public JingleSessionCompleteTest(XMPPConnection con, TransportResolver tr1) {

        this.con = con;

        try {
            System.out.println("Resolver Started");
            tr1.resolve();
        }
        catch (XMPPException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        try {
            while (!tr1.isResolved()) {
                System.out.println("resolving...");
                Thread.sleep(1000);
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }

        System.out.println(tr1.getCandidate(0).getLocalIp());

        jm = new JingleManager(con, tr1);

        jm.addJingleSessionRequestListener(this);

    }

    private ArrayList getTestPayloads1() {
        ArrayList result = new ArrayList();

        result.add(new PayloadType.Audio(0, "PCMU", 1, 8000));
        result.add(new PayloadType.Audio(3, "GSM", 1, 16000));

        return result;
    }

    public void initSession(String jid) {
        if (isSessionOpened()) return;
        try {
            js = jm.createOutgoingJingleSession(
                    jid, getTestPayloads1());

            js.addListener(this);

            js.start(null);
            System.out.println("initSession");
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    public boolean isSessionOpened() {
        return (js != null && js.isFullyEstablished());
    }

    public void endSession() {
        if (js != null) {
            try {
                js.terminate();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                js = null;
            }
        }
    }

    /**
     * Called when a new session request is detected
     */
    public void sessionRequested(
            final JingleSessionRequest request) {
        System.out
                .println("Session request detected, from "
                        + request.getFrom()
                        + ": accepting.");

        // We accept the request
        if (isSessionOpened()) return;
        js = request
                .accept(getTestPayloads1());
        js.addListener(this);
        try {
            js.start(request);
            System.out.println("Accepted and Started.");
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    public void sessionEstablished(PayloadType arg0, TransportCandidate arg1,
                                   TransportCandidate arg2) {

        try {

            //SimpleEventHandler eventHandler = new SimpleEventHandler();
            //session = AudioTest.createSession(arg2.getLocalIp(), arg2.getPort(), arg1.getIp(), arg1.getPort(), eventHandler, 5, false, true);
            //eventHandler.setSession(session);

            //System.out.println(arg1.getLocalIp() + "->" + arg1.getIp());
            //System.out.println(arg1.getPort());

            //System.out.println(arg2.getLocalIp() + "->" + arg2.getIp());
            //System.out.println(arg2.getPort());

            //System.out.println(arg0.getId());
            //System.out.println(arg0.getChannels());
            //System.out.println(arg0.getName());

            System.out.println("Estabilished");

        }
        catch (Exception e) {
            System.out.println("ERRO: " + e);
        }
        finally {
        }

    }

    public void sessionDeclined(String arg0) {
        // TODO Auto-generated method stub

    }

    public void sessionRedirected(String arg0) {
        // TODO Auto-generated method stub

    }

    public void sessionClosed(String arg0) {
        // TODO Auto-generated method stub
        System.out.println("Closed " + con.getUser());
        System.out.println(arg0);
    }

    public void sessionClosedOnError(XMPPException arg0) {
        // TODO Auto-generated method stub
        // TODO Auto-generated method stub
        System.out.println("Closed WITH ERROR");
        //System.out.println(arg0);
    }


    public static void main(String args[]) {

        try {
            ProviderManager.addIQProvider("jingle",
                    "http://jabber.org/protocol/jingle", new JingleProvider());

            XMPPConnection x0 = new XMPPConnection("jivesoftware.com");
            XMPPConnection x1 = new XMPPConnection("jivesoftware.com");

            x0.connect();
            x0.login("barata7", "t4zr69");
            x1.connect();
            x1.login("barata6", "t4zr69");

            JingleSessionCompleteTest jsc0 = new JingleSessionCompleteTest(
                    x0, new FixedResolver("200.233.135.155", 20004));
            JingleSessionCompleteTest jsc1 = new JingleSessionCompleteTest(
                    x1, new FixedResolver("200.233.135.155", 20004));

            jsc0.initSession("barata6@jivesoftware.com/Smack");
            Thread.sleep(10000);
            jsc0.endSession();
            Thread.sleep(15000);

            jsc1.initSession("barata7@jivesoftware.com/Smack");
            Thread.sleep(10000);
            jsc0.endSession();
            Thread.sleep(15000);

            jsc0.initSession("barata6@jivesoftware.com/Smack");
            Thread.sleep(10000);
            jsc1.endSession();
            Thread.sleep(10000);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

}
