package org.jivesoftware.smackx.provider;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.jivesoftware.smackx.nat.TransportCandidate;
import org.jivesoftware.smackx.packet.JingleTransport;
import org.jivesoftware.smackx.packet.JingleTransport.JingleTransportCandidate;
import org.xmlpull.v1.XmlPullParser;

/**
 * Provider for a Jingle transport element
 * 
 * @author Alvaro Saurin <alvaro.saurin@gmail.com>
 */
public abstract class JingleTransportProvider implements PacketExtensionProvider {

	/**
	 * Creates a new provider. ProviderManager requires that every
	 * PacketExtensionProvider has a public, no-argument constructor
	 */
	public JingleTransportProvider() {
		super();
	}

	/**
	 * Obtain the corresponding JingleTransport instance.
	 * 
	 * @return a new JingleTransport instance
	 */
	protected JingleTransport getInstance() {
		return new JingleTransport();
	}

	/**
	 * Parse a iq/jingle/transport element.
	 * 
	 * @param parser the structure to parse
	 * @return a transport element.
	 * @throws Exception
	 */
	public PacketExtension parseExtension(final XmlPullParser parser) throws Exception {
		boolean done = false;
		JingleTransport trans = getInstance();

		while (!done) {
			int eventType = parser.next();
			String name = parser.getName();

			if (eventType == XmlPullParser.START_TAG) {
				if (name.equals(JingleTransportCandidate.NODENAME)) {
					trans.addCandidate(parseCandidate(parser));
				} else {
					throw new Exception("Unknown tag \"" + name + "\" in transport element.");
				}
			} else if (eventType == XmlPullParser.END_TAG) {
				if (name.equals(JingleTransport.NODENAME)) {
					done = true;
				}
			}
		}

		return trans;
	}

	protected abstract JingleTransportCandidate parseCandidate(final XmlPullParser parser)
			throws Exception;

	/**
	 * RTP-ICE profile
	 */
	public static class Ice extends JingleTransportProvider {

		/**
		 * Defauls constructor.
		 */
		public Ice() {
			super();
		}

		/**
		 * Obtain the corresponding JingleTransport.Ice instance.
		 * 
		 * @return a new JingleTransport.Ice instance
		 */
		protected JingleTransport getInstance() {
			return new JingleTransport.Ice();
		}

		/**
		 * Parse a iq/jingle/transport/candidate element.
		 * 
		 * @param parser the structure to parse
		 * @return a candidate element
		 * @throws Exception
		 */
		protected JingleTransportCandidate parseCandidate(XmlPullParser parser) throws Exception {
			TransportCandidate.Ice mt = new TransportCandidate.Ice();

			String channel = parser.getAttributeValue("", "channel");
			String generation = parser.getAttributeValue("", "generation");
			String ip = parser.getAttributeValue("", "ip");
			String name = parser.getAttributeValue("", "name");
			String network = parser.getAttributeValue("", "network");
			String username = parser.getAttributeValue("", "username");
			String password = parser.getAttributeValue("", "password");
			String port = parser.getAttributeValue("", "port");
			String preference = parser.getAttributeValue("", "preference");
			String proto = parser.getAttributeValue("", "proto");

			if (channel != null) {
				mt.setChannel(new TransportCandidate.Channel(channel));
			}

			if (generation != null) {
				try {
					mt.setGeneration(Integer.parseInt(generation));
				} catch (Exception e) {
				}
			}

			if (ip != null) {
				mt.setIp(ip);
			}

			if (name != null) {
				mt.setName(name);
			}

			if (network != null) {
				try {
					mt.setNetwork(Integer.parseInt(network));
				} catch (Exception e) {
				}
			}

			if (username != null) {
				mt.setUsername(username);
			}

			if (password != null) {
				mt.setPassword(password);
			}

			if (port != null) {
				try {
					mt.setPort(Integer.parseInt(port));
				} catch (Exception e) {
				}
			}

			if (preference != null) {
				try {
					mt.setPreference(Integer.parseInt(preference));
				} catch (Exception e) {
				}
			}

			if (proto != null) {
				mt.setProto(new TransportCandidate.Protocol(proto));
			}

			return new JingleTransport.Ice.Candidate(mt);
		}
	}

	/**
	 * Raw UDP profile
	 */
	public static class RawUdp extends JingleTransportProvider {

		/**
		 * Defauls constructor.
		 */
		public RawUdp() {
			super();
		}

		/**
		 * Obtain the corresponding JingleTransport.RawUdp instance.
		 * 
		 * @return a new JingleTransport.RawUdp instance
		 */
		protected JingleTransport getInstance() {
			return new JingleTransport.RawUdp();
		}

		/**
		 * Parse a iq/jingle/transport/candidate element.
		 * 
		 * @param parser the structure to parse
		 * @return a candidate element
		 * @throws Exception
		 */
		protected JingleTransportCandidate parseCandidate(XmlPullParser parser) throws Exception {
			TransportCandidate.Fixed mt = new TransportCandidate.Fixed();

			String generation = parser.getAttributeValue("", "generation");
			String ip = parser.getAttributeValue("", "ip");
			String name = parser.getAttributeValue("", "name");
			String port = parser.getAttributeValue("", "port");

            System.out.println();

            if (generation != null) {
				try {
					mt.setGeneration(Integer.parseInt(generation));
				} catch (Exception e) {
				}
			}

			if (ip != null) {
				mt.setIp(ip);
			}

			if (name != null) {
				mt.setName(name);
			}

			if (port != null) {
				try {
					mt.setPort(Integer.parseInt(port));
				} catch (Exception e) {
				}
			}
			return new JingleTransport.RawUdp.Candidate(mt);
		}
	}
}
